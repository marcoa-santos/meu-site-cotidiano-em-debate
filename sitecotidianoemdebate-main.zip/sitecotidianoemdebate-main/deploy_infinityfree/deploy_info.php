<?php echo 'Deploy realizado em: ' . date('Y-m-d H:i:s'); ?>
